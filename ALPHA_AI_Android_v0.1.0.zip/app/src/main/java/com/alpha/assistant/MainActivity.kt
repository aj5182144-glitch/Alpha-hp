package com.alpha.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("es", "MX")
        }
        setContent { AlphaApp(speak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alpha_reply") }) }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun AlphaApp(speak: (String) -> Unit) {
    val blue = Color(0xFF21C7FF)
    val bg = Color(0xFF050B16)
    var tab by remember { mutableStateOf("Inicio") }
    var input by remember { mutableStateOf("") }
    var voice by remember { mutableStateOf("Femenina / sistema") }
    val messages = remember { mutableStateListOf("ALPHA: Hola. Soy ALPHA. ¿Qué necesitas hacer hoy?") }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }
    fun send() {
        val q = input.trim()
        if (q.isNotEmpty()) {
            messages.add("Tú: $q")
            val reply = when {
                q.contains("hola", true) -> "Hola. Estoy listo para ayudarte."
                q.contains("quién eres", true) || q.contains("quien eres", true) -> "Soy ALPHA, tu asistente Android en versión inicial."
                q.contains("ayuda", true) -> "Puedo conversar, responder algunas consultas básicas y leer mis respuestas en voz alta. Las funciones avanzadas aún están en desarrollo."
                else -> "Te entendí: $q. En esta versión inicial todavía no tengo conectado un servicio de inteligencia artificial en línea."
            }
            messages.add("ALPHA: $reply")
            speak(reply)
            input = ""
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = blue, background = bg, surface = Color(0xFF101C2E), onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(bg).padding(18.dp)) {
            Text("ALPHA", color = blue, fontSize = 32.sp, fontWeight = FontWeight.Black)
            Text("ASISTENTE PERSONAL • v0.1.0", color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Inicio", "Chat", "Módulos", "Ajustes").forEach { label ->
                    FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(18.dp))
            when (tab) {
                "Inicio" -> {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("◉", color = blue, fontSize = 92.sp)
                            Text("SISTEMA EN LÍNEA", color = blue, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Tu centro de control personal", color = Color.LightGray)
                            Spacer(Modifier.height(20.dp))
                            Button(onClick = { tab = "Chat" }) { Text("Abrir asistente") }
                        }
                    }
                }
                "Chat" -> {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(messages) { msg ->
                            Surface(color = Color(0xFF10243A), shape = RoundedCornerShape(14.dp)) {
                                Text(msg, Modifier.fillMaxWidth().padding(13.dp), color = Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).background(Color(0xFF17263A), RoundedCornerShape(12.dp)).padding(14.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), decorationBox = { inner -> if (input.isEmpty()) Text("Escribe aquí…", color = Color.Gray); inner() })
                        Button(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con ALPHA")
                            }
                            runCatching { speechLauncher.launch(intent) }
                        }) { Text("🎙") }
                        Button(onClick = { send() }) { Text("Enviar") }
                    }
                }
                "Módulos" -> {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        ModuleCard("Conversación", "Disponible", blue)
                        ModuleCard("Voz del sistema", "Disponible; depende de las voces instaladas en Android", blue)
                        ModuleCard("Automatización Android", "Pendiente: requiere permisos y confirmación", Color(0xFFFFC857))
                        ModuleCard("IA en línea / IA local", "Pendiente de configurar un proveedor o modelo", Color(0xFFFFC857))
                        ModuleCard("Creador de aplicaciones", "Pendiente de desarrollo", Color(0xFFFFC857))
                    }
                }
                else -> {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Voz de respuesta", color = blue, fontWeight = FontWeight.Bold)
                        Text("La voz y el género dependen de las voces instaladas en tu teléfono.")
                        listOf("Femenina / sistema", "Masculina / sistema").forEach { option ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = voice == option, onClick = { voice = option })
                                Text(option)
                            }
                        }
                        Button(onClick = { speak("Prueba de voz de ALPHA.") }) { Text("Probar voz") }
                        Text("Privacidad", color = blue, fontWeight = FontWeight.Bold)
                        Text("El micrófono solo se activa cuando pulsas el botón de voz. Esta versión no ejecuta acciones del teléfono por su cuenta.")
                        Text("Versión 0.1.0 • Funciones avanzadas aún no conectadas.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
            Text("ALPHA • Control con permiso del usuario", color = Color(0xFF6F829A), fontSize = 10.sp)
        }
    }
}

@Composable
fun ModuleCard(title: String, detail: String, accent: Color) {
    Surface(color = Color(0xFF101C2E), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, color = accent, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(detail, color = Color.LightGray, fontSize = 13.sp)
        }
    }
}
